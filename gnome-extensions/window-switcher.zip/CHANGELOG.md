## [v8](https://github.com/lepa22/window-app-switcher-on-active-monitor/compare/v7...v8)(2023-04-18)

- Added support for GNOME 44

## [v7](https://github.com/lepa22/window-app-switcher-on-active-monitor/compare/v6...v7)(2022-12-02)

- Forked original extension
- Renamed forked exension
- **extension:** Used `ExtensionUtils.getSettings` instead of custom function

## [v6](https://github.com/gedzeppelin/monitor-window-switcher/compare/v5...v6) (2021-11-19)

### Fix

- **extension:** Create settings on extension enable.

## [v5](https://github.com/gedzeppelin/monitor-window-switcher/compare/v4...v5) (2021-11-10)

### Fix

- **extension:** Destroy settings on extension disable.

# [v4](https://github.com/gedzeppelin/monitor-window-switcher/compare/v3...v4) (2021-11-10)

### Feature

- **extension:** Add app switcher support with workplace and window filter.

### Refactor

- **repo:** README updated. 

## [v3](https://github.com/gedzeppelin/monitor-window-switcher/compare/v2...v3) (2021-04-26)

### Refactor

- **extension:** use three top-level functions instead of class.

## [v2](https://github.com/gedzeppelin/monitor-window-switcher/compare/v1...v2) (2021-04-25)

### Feature

- **prefs:** add preferences dialog.
